from ._tsl_type_parser import Type as TSLTypeParser
from ._tsl_type_parser import *
from Ruikowa.ErrorFamily import handle_error
TSLTypeParse = handle_error(TSLTypeParser)

